require 'rails_helper'
describe Movie do
end